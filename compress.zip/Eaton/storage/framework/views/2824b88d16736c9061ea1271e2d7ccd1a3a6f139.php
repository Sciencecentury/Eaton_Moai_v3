<?php $__env->startSection('title', '予定変更 '); ?>

<?php $__env->startSection('body'); ?>

  <?php if($errors -> any()): ?>
        <div class= "top_errors_msg"><?php echo e($errors -> first('password')); ?>

          <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php echo e($error); ?><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  </div>
    <?php endif; ?>

<div class = "addEventBackColor">
<h1 class = "addEventMainTitle">予定の編集</h1>

<div class="changeEvent_p">
    <p>編集する予定のタイトル</p>
</div>

<form action = "<?php echo e(route('eventChange')); ?>" method = "post">
<?php echo csrf_field(); ?>
<div class="Event_labels"> 
    <!-- タイトル設定部分 -->
    <!-- 組設定部分 -->
    <?php
	$titles = \DB::table('titles')->get();

    ?>
	<!--テスト-->
	<?php
                $title = $changeTask[0] -> title;

        ?>



    タイトル<input list = "testList"  class = "Event_label_title" name = "title" required placeholder='変更前：<?php echo e($title); ?>'>
    <datalist id="testList">


<!--	<?php 
		$title = $changeTask[0] -> title; 
	?> 
-->

	<?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($val -> title == $title): ?>
			<option value='<?php echo e($val->title); ?>' selected><?php echo e($val->title); ?></option>
		<?php else: ?>
			<option value='<?php echo e($val->title); ?>'><?php echo e($val->title); ?></option>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


     </datalist>
     <!-- テンプレ追加のボタン -->
     <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 組設定部分 -->
    <?php
        $classes = \DB::table('classes')->get();
    ?>
    組<select name="class" class="Event_label_class">
		<?php
			$class = $changeTask[0] -> class;
		?>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($val -> class == $class): ?>
	            <option value='<?php echo e($val->class); ?>' selected><?php echo e($val->class); ?></option>
				<?php else: ?> 
	            <option value='<?php echo e($val->class); ?>'><?php echo e($val->class); ?></option>
				<?php endif; ?>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <!-- テンプレ追加のボタン -->
    <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 場所設定部分 -->
    <?php
        $places = \DB::table('places')->get();
    ?>
    場所<select name="place" class="Event_label_place">
		<?php
			$place = $changeTask[0] -> place;
		?>
        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($val -> place == $place): ?>
	            <option value='<?php echo e($val->place); ?>' selected><?php echo e($val->place); ?></option>
				<?php else: ?> 
	            <option value='<?php echo e($val->place); ?>'><?php echo e($val->place); ?></option>
				<?php endif; ?>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <!-- テンプレ追加のボタン -->
    <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 時間設定部分 -->
    <div>
        <div>
            <label>日時</label><br>
            <span>開始日時：</span>
            <input type = "date" name = "start_date" id = "startDay" class="Event_startDay"  value = "<?php echo e($changeTask[0] -> start_date); ?>" required>
            <input type = "time" name = "start_time" id = "starTime" class="Event_startTime" value = "<?php echo e($changeTask[0] -> start_time); ?>">
        </div>

        <div class="Event_end_div">
            <span>終了日時：</span>
            <input type = "date" name = "end_date" id = "endDay" class="Event_endDay" value = "<?php echo e($changeTask[0] -> end_date); ?>" required>
            <input type = "time" name = "end_time" id = "endTime" class="Event_endTime" value = "<?php echo e($changeTask[0] -> end_time); ?>">
        </div>
    </div>

    <!-- 備考記述部分 -->
    備考<br>
    <!--<input type = "text" name="remarks"><br>
	--><textarea name="remarks" cols="30" rows="10" maxlength="200" class="Event_remarks"><?php echo e($changeTask[0] -> remarks); ?></textarea><br>
	</div>
	
    <input type = "hidden" name = "userName" value = "<?php echo e($changeTask[0] -> userName); ?>">
    <input type = "hidden" name = "id" value = "<?php echo e($changeTask[0] -> id); ?>">

    <div class="Event_buttons">
	    <!-- 追加・キャンセルボタン -->
	    <input type = "submit" value = "変更" class="add_ok_button">
    </div>
</form>

    <form  method = "post" action = <?php echo e(route ('index')); ?>>
        <?php echo csrf_field(); ?>
        <input type = "submit" class = "Event_cancel" value = "キャンセル">
    </form>
</div>
<!-- -------------------------------------------------------------------------- -->
<!-- 各種テンプレ―ト追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<!-- --------------------------------------------------------------------------* -->
<!-- タイトル追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">タイトルのテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route ('addTmp')); ?>>
            <?php echo csrf_field(); ?>
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "titles">
            <input type = "hidden" name = "origin" value = <?php echo e($changeTask); ?>>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>

<!-- クラス追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">組のテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route('addTmp')); ?>>
            <?php echo csrf_field(); ?>
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "classes">
            <input type = "hidden" name = "origin" value = <?php echo e($changeTask); ?>>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>

<!-- 場所追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">場所のテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route('addTmp')); ?>>
            <?php echo csrf_field(); ?>
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "places">
            <input type = "hidden" name = "origin" value = <?php echo e($changeTask); ?>>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eaton\resources\views/changeEvent.blade.php ENDPATH**/ ?>