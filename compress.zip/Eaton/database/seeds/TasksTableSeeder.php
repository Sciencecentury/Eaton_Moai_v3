<?php

use Illuminate\Database\Seeder;

class TasksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $task = [

            [
                'userName'=>'桃井',
                'title'=>'交通安全教室',
                'class'=>'全クラス',
                'place'=>'中庭',
                'start_date'=>'2019-10-28',
                'start_time'=>'10:00',
                'end_date'=>'2019-10-28',
                'end_time'=>'12:00',
                'remarks'=>'ボランティアの方が5人来園',
                'last_editor'=>'牧野'
            ],
            [
                'userName'=>'月成',
                'title'=>'身体測定',
                'class'=>'ちゅーりっぷ',
                'place'=>'中庭',
                'start_date'=>'2019-10-29',
                'start_time'=>'10:00',
                'end_date'=>'2019-10-29',
                'end_time'=>'11:00',
                'remarks'=>'教師2人徴収',
                'last_editor'=>'牧野'
            ],
            [
            'userName'=>'鈴鹿',
            'title'=>'お楽しみ会',
            'class'=>'無し',
            'place'=>'園外',
            'start_date'=>'2019-10-30',
            'start_time'=>'10:00',
            'end_date'=>'2019-10-30',
            'end_time'=>'20:00',
            'remarks'=>'県外に研修',
            'last_editor'=>'牧野',
            ],
            [
                'userName'=>'茂木',
                'title'=>'家庭訪問',
                'class'=>'無し',
                'place'=>'社内',
                'start_date'=>'2019-10-30',
                'start_time'=>'09:00',
                'end_date'=>'2019-10-30',
                'end_time'=>'20:00',
                'remarks'=>'OIC生3名1日インターン',
                'last_editor'=>'牧野'
            ],
            [
                'userName'=>'千原',
                'title'=>'個人懇談',
                'class'=>'ばら',
                'place'=>'園外',
                'start_date'=>'2019-10-30',
                'start_time'=>'10:00',
                'end_date'=>'2019-10-30',
                'end_time'=>'14:00',
                'remarks'=>'後楽園見学',
                'last_editor'=>'牧野'
            ]

        ];
        DB::table('tasks')->insert($task);

    }
}
