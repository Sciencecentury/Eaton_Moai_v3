<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\ChangeSchedule;
use Illminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Validator;
/*--------------------------------------------------------------------------
予定の編集に関するコントローラ
--------------------------------------------------------------------------*/
class ChangeEventController extends Controller
{
    // 予定変更の画面を表示するメソッド
    public function changeWindow (Request $request) {
        // 持ってきたタスクのidを変数に保存
        $taskId = $request->taskId;
        $intId = intval($taskId);
        // dbからidに関連する情報を持ってくる
        $changeTask = \DB::table('tasks') -> select('*') -> where('id', '=', $intId) -> get();      

        return view('changeEvent',['changeTask' => $changeTask]);
    }

    // 編集ボタンを押下した後の処理
	public function changeStore(Request $request){

        $request -> validate ([
                'title' => 'max : 12',
        ]);
	
        $request -> validate ([
                'remarks' => 'max : 10',
        ]);

       $end_date = $request -> end_date;
       $end_time = $request -> end_time;
       $start_date = $request -> start_date;
       $start_time = $request -> start_time;

       $request -> validate ([
          'end_date' => 'after_or_equal :start_date',
       ]);

       if(!strcmp($end_date, $start_date) && !empty($start_date) && !empty($end_date)){
          $request -> validate ([
             'end_time' => 'after_or_equal :start_time',
          ]);
       }

	//	持ってきたタスクのidを取得する
      $taskId = $request->id;
      $intId = intval($taskId);

     // dbからidに関連する情報を持ってくる
      $changeTask = \DB::table('tasks') -> select('*') -> where('id', '=', $intId) -> get();      
		
		ChangeSchedule::changeStore($request);
      return redirect('');            
   }
}
