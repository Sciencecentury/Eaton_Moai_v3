<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form_data', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('corp_name',100);
            $table->string('user_name',100);
            $table->string('ja_char',100);
            $table->integer('participants'/*,11*/);
            $table->string('visit_day',11);
            $table->string('start_time',8);
            $table->string('end_time',8);
            $table->string('mail_address',100);
            $table->string('tel_num',20);
            $table->string('birthday',12);
            $table->string('postal_code',12);
            $table->string('Prefectures',10);
            $table->string('Address',100);
            $table->integer('lunch_amount'/*,11*/);
            $table->string('support_item',15);
            $table->string('support_content',200)->nullable();
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form_data');
    }
}
