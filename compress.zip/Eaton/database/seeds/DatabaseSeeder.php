<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(CalendarTableSeeder::class);
        $this->call(ClassesTableSeeder::class);
        $this->call(Mail_formTableSeeder::class);
        $this->call(PlacesTableSeeder::class);
        $this->call(TitlesTableSeeder::class);
        $this->call(TasksTableSeeder::class);
        $this->call(Form_dataTableSeeder::class);
    }
}
