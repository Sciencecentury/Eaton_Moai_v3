<?php $__env->startSection('title', 'ログイン'); ?>

<?php $__env->startSection('body'); ?>
    <div class = "loginBackColor">
        <h1 class = "mainTitle">ログイン</h1>

        <!-- Authによっていい感じになるらしい -->
        <form action = "<?php echo e(route('login')); ?>"　name = "loginForm" method = "post">

            <label for = "userName">ユーザ名</label>
            <input type  = "text" name = "userName">          

            <label for = "password">パスワード</label>
            <input type = "password" name = "password">
                            
    <span> <!--spanはインライン要素らしい-->
            <input type = "hidden" value = "in" name = "in">    
            <input type = "submit" class = "sendButton sendData"  value = "ログイン">
        </form>

        <!-- カレンダー画面へ -->
        <a href = "../calendar/calendar.php" class = "sendButton sendData">キャンセル</a>
        <!-- 新規登録画面へ -->
        <a href = "../signUp/signUp.php" class = "sendData" style = "font-size : 17px">新規登録</a>
    </span>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/login/login.blade.php ENDPATH**/ ?>