@extends('layout.default')

@section('title', '予定変更 ')

@section('body')

  @if ($errors -> any())
        <div class= "top_errors_msg">{{$errors -> first('password')}}
          @foreach ($errors -> all() as $error)
             {{$error}}<br>
          @endforeach
	  </div>
    @endif

<div class = "addEventBackColor">
<h1 class = "addEventMainTitle">予定の編集</h1>

<div class="changeEvent_p">
    <p>編集する予定のタイトル</p>
</div>

<form action = "{{route('eventChange')}}" method = "post">
@csrf
<div class="Event_labels"> 
    <!-- タイトル設定部分 -->
    <!-- 組設定部分 -->
    @php
	$titles = \DB::table('titles')->get();

    @endphp
	<!--テスト-->
	@php
                $title = $changeTask[0] -> title;

        @endphp



    タイトル<input list = "testList"  class = "Event_label_title" name = "title" required placeholder='変更前：{{$title}}'>
    <datalist id="testList">


<!--	@php 
		$title = $changeTask[0] -> title; 
	@endphp 
-->

	@foreach ($titles as $val)
		@if($val -> title == $title)
			<option value='{{$val->title}}' selected>{{$val->title}}</option>
		@else
			<option value='{{$val->title}}'>{{$val->title}}</option>
		@endif
	@endforeach


     </datalist>
     <!-- テンプレ追加のボタン -->
     <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 組設定部分 -->
    @php
        $classes = \DB::table('classes')->get();
    @endphp
    組<select name="class" class="Event_label_class">
		@php
			$class = $changeTask[0] -> class;
		@endphp
        @foreach ($classes as $val)
				@if($val -> class == $class)
	            <option value='{{$val->class}}' selected>{{$val->class}}</option>
				@else 
	            <option value='{{$val->class}}'>{{$val->class}}</option>
				@endif
		  @endforeach
        </select>
    <!-- テンプレ追加のボタン -->
    <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 場所設定部分 -->
    @php
        $places = \DB::table('places')->get();
    @endphp
    場所<select name="place" class="Event_label_place">
		@php
			$place = $changeTask[0] -> place;
		@endphp
        @foreach ($places as $val)
				@if($val -> place == $place)
	            <option value='{{$val->place}}' selected>{{$val->place}}</option>
				@else 
	            <option value='{{$val->place}}'>{{$val->place}}</option>
				@endif
		  @endforeach
    </select>
    <!-- テンプレ追加のボタン -->
    <input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>

    <!-- 時間設定部分 -->
    <div>
        <div>
            <label>日時</label><br>
            <span>開始日時：</span>
            <input type = "date" name = "start_date" id = "startDay" class="Event_startDay"  value = "{{$changeTask[0] -> start_date}}" required>
            <input type = "time" name = "start_time" id = "starTime" class="Event_startTime" value = "{{$changeTask[0] -> start_time}}">
        </div>

        <div class="Event_end_div">
            <span>終了日時：</span>
            <input type = "date" name = "end_date" id = "endDay" class="Event_endDay" value = "{{$changeTask[0] -> end_date}}" required>
            <input type = "time" name = "end_time" id = "endTime" class="Event_endTime" value = "{{$changeTask[0] -> end_time}}">
        </div>
    </div>

    <!-- 備考記述部分 -->
    備考<br>
    <!--<input type = "text" name="remarks"><br>
	--><textarea name="remarks" cols="30" rows="10" maxlength="200" class="Event_remarks">{{$changeTask[0] -> remarks}}</textarea><br>
	</div>
	
    <input type = "hidden" name = "userName" value = "{{$changeTask[0] -> userName}}">
    <input type = "hidden" name = "id" value = "{{$changeTask[0] -> id}}">

    <div class="Event_buttons">
	    <!-- 追加・キャンセルボタン -->
	    <input type = "submit" value = "変更" class="add_ok_button">
    </div>
</form>

    <form  method = "post" action = {{route ('index') }}>
        @csrf
        <input type = "submit" class = "Event_cancel" value = "キャンセル">
    </form>
</div>
<!-- -------------------------------------------------------------------------- -->
<!-- 各種テンプレ―ト追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<!-- --------------------------------------------------------------------------* -->
<!-- タイトル追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">タイトルのテンプレートを追加</h2>
        <form method = "post" action = {{route ('addTmp') }}>
            @csrf
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "titles">
            <input type = "hidden" name = "origin" value = {{$changeTask}}>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>

<!-- クラス追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">組のテンプレートを追加</h2>
        <form method = "post" action = {{route('addTmp')}}>
            @csrf
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "classes">
            <input type = "hidden" name = "origin" value = {{$changeTask}}>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>

<!-- 場所追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">場所のテンプレートを追加</h2>
        <form method = "post" action = {{route('addTmp')}}>
            @csrf
            <div class="AddTemp_TextLabels">
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "places">
            <input type = "hidden" name = "origin" value = {{$changeTask}}>
            </div>
            <div class="Addtemp_Bottons">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
</div>
    </div>
