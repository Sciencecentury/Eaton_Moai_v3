﻿<!-- --------------------------------------------------------------------------
このファイルは、laravelファイルの中ですべてのファイルと共通した部分を記述している。
このテンプレを使用したいファイルにこのファイルをimportして使う
＠yieldここに差分を記述する。埋めなかったらnull値になる
-------------------------------------------------------------------------- -->
<!DOCTYPE html>
<html lang = "ja">
<head>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <!-- <meta http-equiv = "X-UA-Compatible" content = "ie=edge"> -->

    <!-- タイトル -->
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- javascript -->
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
    <script src = "<?php echo e(asset('js/all.js')); ?>" defer></script>

    <!-- フォント -->
    <link href = "https://fonts.googleapis.com/css?family=Kosugi+Maru&display=swap" rel = "stylesheet" type = "text/css">

    <link href = "<?php echo e(asset('css/all.css')); ?>" rel = "stylesheet">
</head>
<body>
<!-------------------------------------------------------------------------------------------------->
<!-- にょきっとばー -->
<!-- ログイン状態に応じてにょきっとばーの項目の表示が変わる -->
<!-------------------------------------------------------------------------------------------------->
    <!-- ログイン済みかどうかを判断 -->
    <?php if(Auth::check()): ?>
        <!-- ログイン後の表示 -->
           <a class = "drawrOpenBtn"></a>
            <div class = "drawrMenu">
                <div class = "menuHead">Menu</div>
                <ul class = "drawerList">
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route('logout')); ?>">ログアウト</a></li>
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route ('addEvent')); ?>">予定追加</a></li>
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route('index')); ?>">トップページ</a></li>
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route('templateDelete')); ?>">テンプレート削除</a></li>
                        <hr class = "bar">
                    </ul>
            </div>
        <!-- ログインしているユーザの名まえを表示 -->
            <div class = "uname"><?php echo e(\Auth::user() -> name); ?>さん</div><br>
    <?php else: ?>
        <!-- ログイン前の表示 -->
            <a class = "drawrOpenBtn"></a>
            <!-- ドロワーの中身 -->
            <div class = "drawrMenu">
                <div class = "menuHead">Menu</div>
                <ul class = "drawerList">
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route('register')); ?>">新規登録</a></li>
                        <hr class = "bar">     
                    <li><a  class = "authLink" href = "<?php echo e(route('login')); ?>">ログイン</a></li>
                        <hr class = "bar">
                    <li><a  class = "authLink" href = "<?php echo e(route('index')); ?>">トップページ</a></li>
                        <hr class = "bar">
                </ul>
            </div>
        <!-- ログインしていないため、ゲストさんと表示   -->
            <span class = "uname">ゲストさん</span><br>
    <?php endif; ?>

    <?php echo $__env->yieldContent('body'); ?>
</body>
</html><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/layout/default.blade.php ENDPATH**/ ?>