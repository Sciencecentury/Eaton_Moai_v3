<?php

use Illuminate\Database\Seeder;

class Form_dataTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $form_data = [
            [
                'corp_name'=>'（株）山田商事50',
                'user_name'=>'山田50',
                'ja_char'=>'山田charn',
                'participants'=>'10',
                'visit_day'=>'2019-09-20',
                'start_time'=>'00:00',
                'end_time'=>'13:00',
                'mail_address'=>'山田50@ya.ma.da.jp',
                'tel_num'=>'222-2222-2222',
                'birthday'=>'2019-11-09',
                'postal_code'=>'111-1111',
                'Prefectures'=>'山田県',
                'Address'=>'山田県山田市山田町50-50',
                'lunch_amount'=>'1919',
                'support_item'=>'山田50',
                'support_content'=>'山田商事株式会社の支店設立'
            ],
            [
                'corp_name'=>'（株）山田商事60',
                'user_name'=>'山田60',
                'ja_char'=>'山田charn',
                'participants'=>'20',
                'visit_day'=>'2019-09-13',
                'start_time'=>'00:00',
                'end_time'=>'13:00',
                'mail_address'=>'山田50@ya.ma.da.jp',
                'tel_num'=>'222-2222-2222',
                'birthday'=>'2019-11-09',
                'postal_code'=>'111-1111',
                'Prefectures'=>'山田県',
                'Address'=>'山田県山田市山田町60-60',
                'lunch_amount'=>'1919',
                'support_item'=>'山田60',
                'support_content'=>'山田商事株式会社の支店設立'
            ]
        ];
        DB::table('form_data')->insert($form_data);
    }
}
