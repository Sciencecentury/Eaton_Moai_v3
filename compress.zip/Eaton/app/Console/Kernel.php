<?php

namespace App\Console;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
      .
* @return void
     */
    protected function schedule(Schedule $schedule)
    {

	//----------------------//
	//	毎日実行	//
        //バックアップ処理実行	//
	//----------------------//

       $schedule->call(function () {
            //DB取得
            $tasks = \DB::table('tasks')->get();

            // CSVファイルに書き込む配列を定義します。
            $ary = array(
                array("id","userName","title","class","place","start_date","start_time","end_date","end_time","remarks","last_editor","created_at","updated_at","deleted_at"),
            );

            foreach ($tasks as $task){
                array_push($ary, array($task->id, $task->userName, $task->title, $task->class, $task->place, $task->start_date, $task->start_time, $task->end_date, $task->end_time, $task->remarks, $task->last_editor, $task->created_at, $task->updated_at, $task->deleted_at));
            }

            // ファイルを書き込み用に開きます。

            $f = fopen("/var/www/Eaton/task_back_up/".date("Y_m_")."tasks/".date("Y_m_d_")."tasks_date.csv", "w");
            // 正常にファイルを開くことができていれば、書き込みます。
            if ( $f ) {
                // $ary から順番に配列を呼び出して書き込みます。
                foreach($ary as $line){
                    // fputcsv関数でファイルに書き込みます。
                    fputcsv($f, $line);
                }
            }
            // ファイルを閉じます。
            fclose($f);
	    echo "\nバックアップ成功"; 
	});

	
	//------------------------------//	
	//		毎月実行	//
	//バックアップファイル作成処理	//
	//------------------------------//

	 $schedule->call(function () {

		//作成したいディレクトリパス
		$directory_path = "/var/www/Eaton/task_back_up/".date("Y_m_")."tasks";    //この場合、一つ上の階層に「hoge」というディレクトリを作成する
 
		//「$directory_path」で指定されたディレクトリが存在するか確認
		if(file_exists($directory_path)){
    			//存在したときの処理
    			echo "作成しようとしたディレクトリは既に存在します";
		}else{
    			//存在しないときの処理（「$directory_path」で指定されたディレクトリを作成する）
    			if(mkdir($directory_path, 0777)){
        			//作成したディレクトリのパーミッションを確実に変更
        			chmod($directory_path, 0777);
        			//作成に成功した時の処理
        			echo "作成に成功しました";
    			}else{
        			//作成に失敗した時の処理
        			echo "作成に失敗しました";
    			}
		}
	});

    }


    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
