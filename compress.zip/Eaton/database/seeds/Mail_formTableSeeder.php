<?php

use Illuminate\Database\Seeder;

class Mail_formTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $mail_form = [
            [
                'name'=>'山田11',
                'address'=>'釜山11',
            ],
            [
            'name'=>'山田12',
            'address'=>'釜山12',
            ]
        ];
        DB::table('mail_form')->insert($mail_form);

    }
}
