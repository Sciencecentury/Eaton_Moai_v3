<?php

use Illuminate\Database\Seeder;

class CalendarTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $calendar = [
            [
            'user_name'=>'山田1',
            'title'=>'自己紹介',
            'start_date'=>'09-06',
            'start_time'=>'13:00pm',
            'end_time'=>'15:00pm'
            ],
            ['user_name'=>'山田2',
                'title'=>'自己紹介',
                'start_date'=>'09-07',
                'start_time'=>'13:00pm',
                'end_time'=>'15:00pm'
            ],
            ['user_name'=>'山田3',
                'title'=>'自己紹介',
                'start_date'=>'01-01',
                'start_time'=>'13:00pm',
                'end_time'=>'15:00pm'
            ],
            ['user_name'=>'山田4',
            'title'=>'自己紹介',
            'start_date'=>'01-30',
            'start_time'=>'13:00pm',
            'end_time'=>'15:00pm'
        ],

        ];
        DB::table('calendar')->insert($calendar);

    }
}
