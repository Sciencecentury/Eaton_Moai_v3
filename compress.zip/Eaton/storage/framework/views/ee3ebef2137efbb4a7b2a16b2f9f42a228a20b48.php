<?php $__env->startSection('title', '新規登録'); ?>

<?php $__env->startSection('body'); ?>
<div class = "loginBackColor">
        <h1 class = "mainTitle">新規登録</h1>

        <!-- Authによっていい感じになるらしい -->
        <form action = "<?php echo e(route('register')); ?>"　name = "registerform" method = "post">
            <!-- 入力値チェックええ感じに検査してくれるらしい -->
            <?php echo csrf_field(); ?>
            <!-- $errors -> first（'【フィールド名】'）：　入力した後に入力値をチェックする仕組み（＝バリデーション） -->
            <div class = "login_labels">
            <label for = "name">ユーザ名</label>
            <input type  = "text" name = "name" class = "register_label_name"><span><?php echo e($errors -> first('name')); ?></span><br>       

            <!-- <label for = "email">めあど</label> -->
            <!-- <input type  = "email" name = "email"><span><?php echo e($errors -> first('email')); ?></span><br>        -->

            <label for = "password">パスワード</label>
            <input type = "password" name = "password" class = "register_label_password"><span><?php echo e($errors -> first('password')); ?></span><br>

            <label for = "password">パスワード(確認用)</label>
            <input type = "password" name = "password_confirmation" class = "register_label_password_confirmation"><span><?php echo e($errors -> first('password_confirmation')); ?></span><br>

    <span> <!--spanはインライン要素らしい-->
            <input type = "submit" name = "action" class = "Registration_button" value = "登録">
        </form>

        <!-- カレンダー画面へ -->
        <form  method = "post" action = <?php echo e(route ('index')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "submit" class = "register_cancel_button" value = "キャンセル">
        </form>
    </span>
</div>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/auth/register.blade.php ENDPATH**/ ?>