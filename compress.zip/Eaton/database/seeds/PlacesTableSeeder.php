<?php

use Illuminate\Database\Seeder;

class PlacesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $place = [
            ['place'=>'指定なし'],
            ['place'=>'玄関'],
            ['place'=>'階段'],
            ['place'=>'事務室1F'],
            ['place'=>'WC1F'],
            ['place'=>'調理室'],
            ['place'=>'多目的室1F'],
            ['place'=>'保育室1F'],
            ['place'=>'保育室2F'],
            ['place'=>'遊戯室2F'],
            ['place'=>'園庭'],
            ['place'=>'園外']

        ];
        DB::table('places')->insert($place);
    }
}
