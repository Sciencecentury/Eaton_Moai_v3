<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use App\Models\AddSchedule;
use Carbon\Carbon;
use App\Models\TimeJudgment;
use App\Models\LengthJudgment;
use Validator;
/*--------------------------------------------------------------------------
addEvent.php(カレンダーの画面)にアクセスがあったときに動くコントローラー
--------------------------------------------------------------------------*/
class AddEventController extends Controller
{
    // 予定追加画面への遷移
    public function addEvent(){
        return view('addEvent');
    }
    
    public function addStore(Request $request){
        // 予定の文字数の判定をするクラス。上限は12文字なので、12文字以下かどうかを判定する
		$request -> validate ([
			'title' => 'max : 12',
		]);

   	// 日付の判定をするクラス。論理的に正しければdbに保存する
		$end_date = $request -> end_date;
		$end_time = $request -> end_time;
		$start_date = $request -> start_date;
		$start_time = $request -> start_time;

		$request -> validate ([
			'end_date' => 'after_or_equal :start_date',
		]);
		
       if(!strcmp($end_date, $start_date) && !empty($start_time) && !empty($end_time)){
			$request -> validate ([
				'end_time' => 'after_or_equal :start_time',
			]);
		}

		$request -> validate ([
			'remarks' => 'max : 200',
		]);

   	//インスタンスを生成
      $task = new AddSchedule;
      $task -> addStore($request);
      	return redirect('');            
    }
}

