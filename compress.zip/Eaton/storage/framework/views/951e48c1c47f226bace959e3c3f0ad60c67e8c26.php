<?php $__env->startSection('title', '新規登録'); ?>

<?php $__env->startSection('body'); ?>
        <table class = "textBox" align = "center">
                <tr>
                    <td>ユーザ名</td>
                    <td><input type = "text" name = "userName"></td>
                </tr>
                <tr>
                    <td>パスワード</td>
                    <td><input type = "password" name = "password"></td>
                </tr>
                <tr>
                    <td>パスワード(確認用)</td>
                    <td><input type = "password" name = "checkPassword"></td>
                </tr>
            </table>
            <input type = "hidden" value = "signUp" name = "signUp">
            <span>
                <input type = "submit" class = "sendButton sendData"  value = "登録">
	    </form>
        <!-- カレンダー画面へ -->
        <a href = "../calendar/calendar.php" class = "sendButton sendData">キャンセル</a>
    </span>
    </div>
</body>
</html>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/signUp/signUp.blade.php ENDPATH**/ ?>