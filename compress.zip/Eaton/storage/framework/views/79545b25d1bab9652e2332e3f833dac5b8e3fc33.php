<?php $__env->startSection('title', 'カレンダー'); ?>

<?php $__env->startSection('body'); ?>
<!-------------------------------------------------------------------------------------------------->
<!-- 今日の日付を取得・表示 -->
<!-------------------------------------------------------------------------------------------------->
  <div class = "today"><?php echo e($today); ?></div><br>


<div align="right">
<form  method = "post" action = <?php echo e(route ('indexCSV')); ?>>
<?php echo csrf_field(); ?>
    <input type = "hidden" name = "whiteCSV" value = "Go">
    <input type = "submit" class = "submitCSV" value = "バックアップを取る">
</form>
</div>


<!-------------------------------------------------------------------------------------------------->
<!-- 一週間カレンダーの月移動矢印-->
<!-------------------------------------------------------------------------------------------------->
<div class="month_div">
<span class = "leftButtonMonth">
  <form  method = "get" action = <?php echo e(route ('indexMonthMove')); ?>>
    <?php echo csrf_field(); ?>
    <input type = "hidden" name = "move" value = "back">
    <input type = "hidden" name = "nowDisplay" value = "<?php echo e($weekStart); ?>">
    <input type = "image" src = "img/left.png" width="40" height="40">
  </form>
</span>
<!-- 一週間カレンダーに表示されている日付の月 -->
<span class = "displayMonth2">
  月：<?php echo e($dates[0] -> month); ?>月
  <?php if($dates[0] -> month != $dates[count($dates)-1] -> month): ?>
        ～<?php echo e($dates[count($dates)-1] -> month); ?>月
  <?php endif; ?>
</span>

<!-- 次の週へ進む -->
<span class = "rightButtonMonth">
    <form  method = "get" action = <?php echo e(route ('indexMonthMove')); ?>>
      <?php echo csrf_field(); ?>
        <input type = "hidden" name = "move" value = "forward">
        <input type = "hidden" name = "nowDisplay" value = "<?php echo e($weekStart); ?>">
        <input type = "image" src = "img/right.png" width="40" height="40">
    </form>
  </span>
</div>

<!-------------------------------------------------------------------------------------------------->
<!-- 一週間カレンダーの週移動矢印-->
<!-------------------------------------------------------------------------------------------------->
<div class="week_div">
<span class = "leftButton">
  <form  method = "post" action = <?php echo e(route ('indexWeekMove')); ?>>
    <?php echo csrf_field(); ?>
    <input type = "hidden" name = "move" value = "back">
    <input type = "hidden" name = "nowDisplay" value = "<?php echo e($weekStart); ?>">
    <input type = "image" src = "img/left.png" width="40" height="40">
  </form>
</span>

<!-- 一週間カレンダーに表示されている日付の月 -->
<span class = "displayMonth">
  週：<?php echo e($dates[0] -> month); ?>月<?php echo e($dates[0] -> day); ?>日～
    <?php if($dates[0] -> month != $dates[count($dates)-1] -> month): ?>
        <?php echo e($dates[count($dates)-1] -> month); ?>月
    <?php endif; ?>
    <?php echo e($dates[count($dates)-1] -> day); ?>日
</span>

<!-- 次の週へ進む -->
<span class = "rightButton">    
    <form  method = "post" action = <?php echo e(route ('indexWeekMove')); ?>>
      <?php echo csrf_field(); ?>
        <input type = "hidden" name = "move" value = "forward">
        <input type = "hidden" name = "nowDisplay" value = "<?php echo e($weekStart); ?>">
        <input type = "image" src = "img/right.png" width="40" height="40">
    </form>
  </span>
</div>


<!-- 現在の週に戻る -->
<span class = "nowWeekBack">
  <form  method = "post" action = <?php echo e(route ('index')); ?>>
    <?php echo csrf_field(); ?>
      <!-- <input type = "hidden" name = "move" value = "forward"> -->
      <!-- <input type = "hidden" name = "nowDisplay" value = "<?php echo e($weekStart); ?>"> -->
      <input type = "submit" class = "nowWeekBackButton" value = "現在の週に戻る">
  </form>
</span>

<!-------------------------------------------------------------------------------------------------->
<!-- 一週間カレンダー・曜日表示 -->
<!-------------------------------------------------------------------------------------------------->
<span>
<table class = "calendarTable">
　<!-- <thead>：テーブルのヘッダ行 -->
  <thead>
    <tr class = "oneWeek">
        <!-- 曜日を出力 -->
        <?php $__currentLoopData = ['日', '月', '火', '水', '木', '金', '土']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayOfWeek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dayOfWeek == "日"): ?>
                <th style = "color : red;"><?php echo e($dayOfWeek); ?></th>
            <?php elseif($dayOfWeek == "土"): ?>
                <th style = "color : blue;"><?php echo e($dayOfWeek); ?></th>
            <?php else: ?>
                <th style = "color : black;"><?php echo e($dayOfWeek); ?></th>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
  </thead>
<!-------------------------------------------------------------------------------------------------->
<!-- 一週間カレンダー・日付表示 -->
<!-------------------------------------------------------------------------------------------------->
  <!-- <tbody>：テーブルのデータ部分 -->
  <tbody>
    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($date -> dayOfWeek == 0): ?>
            <tr>
        <?php endif; ?>
        <!-- 現在選択されている日付が今月のものでなければ背景を暗くする -->
      <td class = "oneWeekDay"
        <?php if($date -> month != date('m')): ?>
            class = "bg-secondary"
        <?php endif; ?>
      >
        <?php echo e($date->day); ?>

      </td>
        <!-- 一週間分表示したら終了 -->
         <?php if($date->dayOfWeek == 7): ?>
           </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-------------------------------------------------------------------------------------------------->
<!-- 一週間カレンダー・予定表示 -->
<!-------------------------------------------------------------------------------------------------->
<tr>
    <!-- 今週の日数分（要は7回）回す -->
      <?php for($roopCountWeek = 0; $roopCountWeek < 7; ++$roopCountWeek): ?>
        <td class = "taskList">
        <!-- 配列に入っているタスクの数だけループさせる -->
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- 現在、指し示している日付と、taskの日付が同じならタイトルを表示する -->  
          <?php if($dates[$roopCountWeek] == $key." 00:00:00"): ?>
            <?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayTask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- 予定のタイトルを表示、クリックで詳細ポップアップを表示する -->


                <!--色変更の処理-->

                <?php ($w = ""); ?>
                <?php ($titles = \DB::table('titles')->get()); ?>
                <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dayTask->title == $title->title): ?>
                        <?php if($w = $title->color): ?><?php endif; ?>
                    <?php else: ?>
                        <!--何らかの原因で色追加できなかった場合グレーに設定(初期値や削除対策)-->
                        <?php if($colorChange = ""): ?><?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($w != null): ?>
                    <?php if($colorChange = $w): ?><?php endif; ?>
                <?php endif; ?>

              <span><input type = "button"  style="background-color: <?php echo e($colorChange); ?>" class = "taskDetailPopupButton" value = "<?php echo e($dayTask -> title); ?>"></span><br>

              <!-- ポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
              <div class = "taskDetailPopup">
                <!-- ポップアップの内容 -->
                <span class = "taskTitle">
                  <?php echo e($dayTask -> title); ?>

                </span>
                <span class = "author">
		  【作成者 ： <?php echo e($dayTask -> userName); ?>】
                  【最終編集者： <?php echo e($dayTask -> last_editor); ?>】  
                </span>
                <span class = "taskDetail">
		  <table class = "taskDetail">
                    <tr><td class = "taskColumn">組</td><td class = "taskData"><?php echo e($dayTask -> class); ?></td></tr>
                    <tr><td class = "taskColumn">場所</td><td class = "taskData"><?php echo e($dayTask -> place); ?></td></tr>
                    <tr><td class = "taskColumn">開始日付</td><td class = "taskData"><?php echo e($dayTask -> start_date); ?></td></tr>
                    <tr><td class = "taskColumn">開始時刻</td><td class = "taskData"><?php echo e($dayTask -> start_time); ?></td></tr>
                    <tr><td class = "taskColumn">終了日時</td><td class = "taskData"><?php echo e($dayTask -> end_date); ?></td></tr>
                    <tr><td class = "taskColumn">終了時刻</td><td class = "taskData"><?php echo e($dayTask -> end_time); ?></td></tr>
                  </table>
                </span>
                <span>
                  <div class = "taskRemarksTitle">備考</div>
                  <div class = "taskRemarksBack"><div class = "taskRemarks"><?php echo e($dayTask -> remarks); ?></div></div>
                </span> 

                <!-- 削除ボタン -->
                <?php if(Auth::check()): ?>
                  <form  method = "post" action = <?php echo e(route ('deleteTask')); ?>>
                    <?php echo csrf_field(); ?>
                    <!-- このタスクのidをhiddenで送る -->
                    <input type = "hidden" name = "taskId" value = "<?php echo e($dayTask -> id); ?>">
                    <input type = "submit" class = "deleteButton" value = "削除">
                  </form>
                <?php endif; ?>
            
                <!-- 閉じるボタン -->
                <input type = "button" class = "closeButton" value = "閉じる"><br>
          
                <?php if(Auth::check()): ?>
                  <!-- 予定編集ボタン -->
                   <form  method = "post" action = <?php echo e(route ('changeEvent')); ?>>
                    <?php echo csrf_field(); ?>
                    <!-- このタスクのidをhiddenで送る -->
                    <input type = "hidden" name = "taskId" value = "<?php echo e($dayTask -> id); ?>">
                    <input type = "submit" class = "editButton" value = "編集">
                  </form>
                <?php endif; ?>
              </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
      <?php endfor; ?>
    </tr>
</tbody>
</table>
</span>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eaton\resources\views/index.blade.php ENDPATH**/ ?>