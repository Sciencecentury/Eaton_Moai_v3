<?php

use Illuminate\Database\Seeder;

class TitlesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $title = [
            ['title'=>'入園式','color'=>"#ffcccc"],
            ['title'=>'お楽しみ会','color'=>"#ffcccc"],
            ['title'=>'家庭訪問','color'=>"#ffcccc"],
            ['title'=>'個人懇談','color'=>"#ffcccc"],
            ['title'=>'交通安全教室','color'=>"#ffcccc"],
            ['title'=>'歯科検診','color'=>"#ffcccc"],
            ['title'=>'健康診断','color'=>"#ffcccc"],
            ['title'=>'七夕会','color'=>"#ffcccc"],
            ['title'=>'お月見会','color'=>"#ffcccc"],
            ['title'=>'運動会','color'=>"#ffcccc"],
            ['title'=>'クリスマス会','color'=>"#ffcccc"],
            ['title'=>'ひな祭り','color'=>"#ffcccc"],
            ['title'=>'卒園式','color'=>"#ffcccc"],
            ['title'=>'防災訓練','color'=>"#ffcccc"],
            ['title'=>'身体計測','color'=>"#ffcccc"],
            ['title'=>'誕生日会','color'=>"#ffcccc"]

        ];
        DB::table('titles')->insert($title);
    }
}
