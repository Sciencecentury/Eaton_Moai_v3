

<?php $__env->startSection('title', '予定変更 '); ?>

<?php $__env->startSection('body'); ?>

<!-- エラー出力 -->
<?php if($errors -> any()): ?>
   <div class= "top_errors_msg"><?php echo e($errors -> first('password')); ?>

      <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class = "addEventBackColor">
<h1 class = "addEventMainTitle">予定の編集</h1>

<div class="changeEvent_p">
    <p>編集する予定のタイトル</p>
</div>
			<?php if($origin == "index"): ?>
       <?php
            $titles = \DB::table('titles')->get();
            $classes = \DB::table('classes')->get();
            $places = \DB::table('places')->get();
				
            	$userName = $changeTask[0] -> userName;
            	$title = $changeTask[0] -> title;
            	$id = $changeTask[0] -> id;
           		$class = $changeTask[0] -> class;
            	$place = $changeTask[0] -> place;
					$start_date = $changeTask[0] -> start_date;
					$start_time = $changeTask[0] -> start_time;
					$end_date = $changeTask[0] -> end_date;
					$end_time = $changeTask[0] -> end_time;
					$remarks = $changeTask[0] -> remarks;
		?>				
			<?php endif; ?>
<form action = "<?php echo e(route('eventChange')); ?>" method = "post">
   <?php echo csrf_field(); ?>
   <div class="Event_labels">

       <!--テンプレートを表示するためにdbからタイトルのテンプレ一覧を取得する-->
       <!--編集しよとしているタスクのタイトルを取得する-->

	 <input type = "hidden" name = "userName" value = "<?php echo e($userName); ?>">
    <input type = "hidden" name = "id" value = "<?php echo e($id); ?>">
	<!-- タイトル設定部分 -->
           タイトル<input list = 'testList'  class = 'Event_label_title' name = 'title' required placeholder = '変更前：<?php echo e($title); ?>'>
           <datalist id='testList'>
           <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($val -> title == $title): ?>
            		<option value='<?php echo e($val->title); ?>' selected><?php echo e($val->title); ?></option>
           		<?php else: ?>
               	<option value='<?php echo e($val->title); ?>'><?php echo e($val->title); ?></option>
           		<?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </datalist>
   			<br> 
            <!-- テンプレ追加のボタン -->
            <!--<input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>-->

<!-- 組設定部分 -->
          組<select name='class' class='Event_label_class'>
          	<?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<?php if($val -> class == $class): ?>
               	<option value='<?php echo e($val->class); ?>' selected><?php echo e($val->class); ?></option>
            	<?php else: ?>
               	<option value='<?php echo e($val->class); ?>'><?php echo e($val->class); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
   			<br> 
            <!-- テンプレ追加のボタン -->
            <!--<input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>-->

<!-- 場所設定部分 -->
          場所<select name='place' class='Event_label_place'>
           	<?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<?php if($val -> place == $place): ?>
               	<option value='<?php echo e($val->place); ?>' selected><?php echo e($val->place); ?></option>
            	<?php else: ?>
               	<option value='<?php echo e($val->place); ?>'><?php echo e($val->place); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    
   			<br> 
            <!-- テンプレ追加のボタン -->
            <!--<input type = "button" class = "addPopupButton" value = " + " onClick = "deleteTextSubmit();"><br>-->

<!-- 時間設定部分 -->              
        <div>
            <div>
					<label>日時</label><br>
               <span>開始日時：</span>
               <input type = "date" name = "start_date" id = "startDay" class="Event_startDay"  value = "<?php echo e($start_date); ?>" required>
               <input type = "time" name = "start_time" id = "starTime" class="Event_startTime" value = "<?php echo e($start_time); ?>">
            </div>
            <div class="Event_end_div">
                <span>終了日時：</span>
                <input type = "date" name = "end_date" id = "endDay" class="Event_endDay" value = "<?php echo e($end_date); ?>" required>
                <input type = "time" name = "end_time" id = "endTime" class="Event_endTime" value = "<?php echo e($end_time); ?>">
            </div>
        </div>

<!-- 備考設定部分 -->
        備考<br>
        <textarea name="remarks" cols="30" rows="10" maxlength="200" class="Event_remarks"><?php echo e($remarks); ?></textarea><br>
   </div>

    <div class="Event_buttons">
       <!-- 追加・キャンセルボタン -->
       <input type = "submit" value = "変更" class="add_ok_button">
    </div>
</form>

<form  method = "post" action = <?php echo e(route ('index')); ?>>
    <?php echo csrf_field(); ?>
    <input type = "submit" class = "Event_cancel" value = "キャンセル">
</form>
</div>
<!-- -------------------------------------------------------------------------- -->
<!-- 各種テンプレ―ト追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<!-- --------------------------------------------------------------------------* -->
<!-- タイトル追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">タイトルのテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route('changeaddTmp')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "titles">
            <input type = "hidden" name = "cname" value = "title">
            <input type = "hidden" name = "dbData" value = "<?php echo e($changeTask); ?>">
            <input type = "hidden" name = "origin" value = <?php echo e($id); ?>>
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
    </div>

<!-- クラス追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">組のテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route('changeaddTmp')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "classes">
            <input type = "hidden" name = "cname" value = "class">
            <input type = "hidden" name = "dbData" value = "<?php echo e($changeTask); ?>">
            <input type = "hidden" name = "origin" value = <?php echo e($id); ?>>
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
    </div>

<!-- 場所追加のポップアップに関する操作・内容。クリックされるまではcssで隠しておく -->
<div class = "addPopup">
        <h2 class = "addtemp_title">場所のテンプレートを追加</h2>
        <form method = "post" action = <?php echo e(route('changeaddTmp')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "text" name = "addTemp" class = "addtemp_text" required><br>
            <input type = "hidden" name = "type" value = "places">
            <input type = "hidden" name = "cname" value = "place">
            <input type = "hidden" name = "origin" value = <?php echo e($id); ?>>
            <input type = "hidden" name = "dbData" value = "<?php echo e($changeTask); ?>">
            <input type = "submit" class = "addtemp_button" value = "追加">
        </form>
        <input type = "button" class = "addPopCloseButton" value = "閉じる">
    </div>
   

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Eaton/resources/views/changeEvent.blade.php ENDPATH**/ ?>