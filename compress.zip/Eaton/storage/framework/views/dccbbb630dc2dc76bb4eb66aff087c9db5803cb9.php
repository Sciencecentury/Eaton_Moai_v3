<?php $__env->startSection('title', 'ログイン'); ?>

<?php $__env->startSection('body'); ?>
    <div class = "loginBackColor">
        <h1 class = "mainTitle">ログイン</h1>
        <?php if(isset($message)): ?>
            <p style = "color : red"><?php echo e($message); ?></p>
        <?php endif; ?>
        <!-- Authによっていい感じになるらしい -->
        <form action = "<?php echo e(route('login')); ?>"　name = "loginform" method = "post">
            <!-- 入力値チェックええ感じにしてくれるらしい -->
            <?php echo csrf_field(); ?>
            <div class="login_labels">
                <label for = "name">ユーザ名</label>
                <input type  = "text" name = "name" value = "<?php echo e(old('name')); ?>"  class="login_label_name"><br>         

                <label for = "password">パスワード</label>
                <input type = "password" name = "password" class="login_label_password"><br>
            </div>

            <span> <!--spanはインライン要素らしい-->
                <div class = "login_buttons"><!--buttonの囲い -->
                    <input type = "submit" name = "action"  class="ok_button" value = "ログイン">
        </form>
        
        <!-- カレンダー画面へ -->
        <form  method = "post" action = <?php echo e(route ('index')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "submit" class = "cancel_button" value = "キャンセル">
        </form>

        <!-- 新規登録画面へ -->
        <li><a class = "link_button" href = "<?php echo e(route('register')); ?>">新規登録</a></li>

            </span>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/auth/login.blade.php ENDPATH**/ ?>