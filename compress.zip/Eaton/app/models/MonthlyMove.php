<?php

namespace App\Models;
if(!isset($_SESSION)){
    session_start();
}
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use \DateTime;

// --------------------------------------------------------------------------------------------------
//月移動するクラス
// --------------------------------------------------------------------------------------------------
class MonthlyMove extends Model{
    public static function monthMove($move, $nowDisplay){

        Carbon::useMonthsOverflow(false);
        // 受け取った文字列型の日付をdate型にする
        $year = substr($nowDisplay, 0, 4);
        $month = substr($nowDisplay, 5, 2);
        $day = substr($nowDisplay, 8, 2);

        $date = Carbon::create(
            $year,
            $month,
            $day
        );

        $date_W = Carbon::create(
            $year,
            $month,
            $day
        );

        //セッションから今の参照日付を取得
        $dateW=$_SESSION['nowday'];
        $arr = explode('.', $dateW);
        $date_W -> year=$arr[0];
        $date_W -> month=$arr[1];
        $date_W -> day=$arr[2];


        // moveの値によって日付を戻すのか進めるのか決める
        switch ($move) {
            case "forward" :
                //日曜日の日時
                $date -> addMonth(1);

                //現在の1か月後の日時
                $date_W -> addMonth(1);
                //セッションに1か月後を追加
                $_SESSION['nowday'] = $date_W->year.".".$date_W->month.".".$date_W->day ;

                $y = $date_W->year;
                $m = $date_W->month;
                $d = $date_W->day;

                $datetime = new DateTime();
                $datetime->setDate((int)$y, (int)$m, (int)$d);
                $w = (int)$datetime->format('w');
                $date = $date_W->subDay($w);

                for ($roopCount = 0; $roopCount < 7; $roopCount++, $date -> addDay()) {
                    $dates[] = $date -> copy();
                }
                break;
            case "back" :

                //日曜日の日時
                $date -> subMonth(1);

                //現在の1か月後の日時
                $date_W -> subMonth(1);


                //セッションに1か月後を追加
                $_SESSION['nowday'] = $date_W->year.".".$date_W->month.".".$date_W->day ;

                $y = $date_W->year;
                $m = $date_W->month;
                $d = $date_W->day;

                $datetime = new DateTime();
                $datetime->setDate((int)$y, (int)$m, (int)$d);
                $w = (int)$datetime->format('w');
                $date = $date_W->subDay($w);

                for ($roopCount = 0; $roopCount < 7; $roopCount++, $date -> addDay()) {
                    $dates[] = $date -> copy();
                }
                break;


            default :
                $date -> addMonth(1);
                for ($roopCount = 0; $roopCount < 7; $roopCount++, $date -> addDay()) {
                    $dates[] = $date -> copy();
                }
        }

        return $dates;
    }



}
