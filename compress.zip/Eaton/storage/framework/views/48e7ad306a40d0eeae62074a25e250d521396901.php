<?php $__env->startSection('title', '予定追加'); ?>

<?php $__env->startSection('body'); ?>
<!--------------------------------------------------------------------------------------------------------->
<!-- 予定追加する画面 -->
<!--------------------------------------------------------------------------------------------------------->
<body>
    予定の追加
    <form action = "" method = "post">
<!--------------------------------------------------------------------------------------------------------->
<!-- タイトル設定部分 -->
<!--------------------------------------------------------------------------------------------------------->
        <label>タイトル</label>
        <input type = "search" autocomplete = "on" list = "optionEventTitle" placeholder = "予定のタイトル" ><!--required-->
            <datalist id = "optionEventTitle">
                <option value = "運動会">
                <option value = "昼寝">
                <option value = "散歩">
            </datalist>
        <a class = "addButton"  id = "titleShow" class = "show">+</a>
            <div id = "titleLayer" class = "layer"></div>
            <div id = "titlePopup" class = "popup">
            <div class = "addEventPopupBackColor">
            <div>タイトルのテンプレートを追加</div>
            <div class = "templateText">タイトル：<input type = "text" name = "eventName"></div><br>
                <!-- ボタン -->
                <input class = "sendButton sendData" value = "登録">
                <input class = "sendButton sendData" id = "titleClose" value = "キャンセル">
               </div>
            </div>
            </div>
<!--------------------------------------------------------------------------------------------------------->
<!-- 組設定部分 -->
<!--------------------------------------------------------------------------------------------------------->
            <div class = "className">
            <label>組</label>
            <input type = "search" name = "className" autocomplete = "on" list = "optionClassName" placeholder = "使用する組">
                <datalist id = "optionClassName">
                    <option value = "さくら">
                    <option value = "ふじ">
                    <option value = "たんぽぽ">
                </datalist>
            <a class = "addButton"  id = "classNameShow" class = "show">+</a>
                <div id = "classNameLayer" class = "layer"></div>
                <div id = "classNamePopup" class = "popup">
                <div class = "addEventPopupBackColor">
                <div>組のテンプレートを追加</div>
                <div class = "templateText">組名：<input type = "text" name = "eventName"></div><br>
                    <!-- ボタン -->
                    <input class = "sendButton sendData" value = "登録">
                    <input class = "sendButton sendData" id = "classNameClose" value = "キャンセル">
                </div>
            </div>
            </div>
<!--------------------------------------------------------------------------------------------------------->
<!-- 場所設定部分 -->
<!--------------------------------------------------------------------------------------------------------->
            <div class = "place">
                <label>場所</label>
                <input type = "search" name = "place"  autocomplete = "on" list = "optionPlace" placeholder = "使用する場所">
                    <datalist id = "optionPlace">
                        <option value = "職員室">
                        <option value = "運動場">
                        <option value = "給食室">
                    </datalist>
                    <a class = "addButton"  id = "placeShow" class = "show">+</a>
                    <div id = "placeLayer" class = "layer"></div>
                    <div id = "placePopup" class = "popup">
                    <div class = "addEventPopupBackColor">
                    <div>場所のテンプレートを追加</div>
                    <div class = "templateText">場所名：<input type = "text" name = "eventName"></div><br>
                        <!-- ボタン -->
                        <input class = "sendButton sendData" value = "登録">
                        <input class = "sendButton sendData" id = "placeClose" value = "キャンセル">
                    </div>
                </div>
                </div>
<!--------------------------------------------------------------------------------------------------------->
<!-- 時間設定部分 -->
<!--------------------------------------------------------------------------------------------------------->
        <div class = "setTime">
            <div class = "start">
            <label for = "note">日時</label><br>
                <span>開始日時：</span>
                <input type = "date" name = "date" id = "startDay">
                <input type = "time" name = "time" id = "starTime">
            </div>

            <div class = "end">
                <span>終了日時：</span>
                <input type = "date" name = "date" id = "endDay">
                <input type = "time" name = "time" id = "endTime">
            </div>
        </div>
<!--------------------------------------------------------------------------------------------------------->
<!-- 備考記述部分 -->
<!--------------------------------------------------------------------------------------------------------->
        <div class = "note">
            <label for = "note">備考</label><br>
            <textarea id = "note" name = "note" cols = "50" rows = "8"></textarea><br>
        </div>
<!--------------------------------------------------------------------------------------------------------->
<!-- 追加・キャンセルボタン -->
<!--------------------------------------------------------------------------------------------------------->
        <input type = "hidden" value = "add" name = "add">
        <input type = "submit" class = "sendButton sendData" value = "追加">
    </form>
    <!-- カレンダー画面へ -->
    <a href = "../calendar/calendar.php" class = "sendButton sendData">キャンセル</a>
</body>
</html>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sasaki\Desktop\xampp\htdocs\Eaton\resources\views/addEvent/addEvent.blade.php ENDPATH**/ ?>