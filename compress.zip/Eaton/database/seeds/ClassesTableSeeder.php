<?php

use Illuminate\Database\Seeder;

class ClassesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
     $class = [

         ['class'=>'指定なし'],
         ['class'=>'全クラス'],

         ['class'=>'ちゅうりっぷ'],
         ['class'=>'0才ちゅうりっぷ1'],
         ['class'=>'0才ちゅうりっぷ2'],
         ['class'=>'0才ちゅうりっぷ3'],

         ['class'=>'ばら'],
         ['class'=>'1才ばら1'],
         ['class'=>'1才ばら2'],
         ['class'=>'1才ばら3'],

         ['class'=>'さくら'],
         ['class'=>'2才さくら1'],
         ['class'=>'2才さくら2'],
         ['class'=>'2才さくら3'],

         ['class'=>'たんぽぽ'],
         ['class'=>'3才たんぽぽ1'],
         ['class'=>'3才たんぽぽ2'],
         ['class'=>'3才たんぽぽ3'],

         ['class'=>'すみれ'],
         ['class'=>'4才すみれ1'],
         ['class'=>'4才すみれ2'],

         ['class'=>'あじさい'],
         ['class'=>'5才あじさい1'],
         ['class'=>'5才あじさい2']
     ];
        DB::table('classes')->insert($class);
    }
}
