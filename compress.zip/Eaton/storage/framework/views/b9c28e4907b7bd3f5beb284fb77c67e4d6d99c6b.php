<?php $__env->startSection('title', '新規登録'); ?>

<?php $__env->startSection('body'); ?>

<!-- エラーメッセージ
   <?php if($errors -> any()): ?>
	<div class="top_errors_msg"><?php echo e($errors -> first('name')); ?>

		<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($error); ?><dr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
   <?php endif; ?>
-->
<div class = "loginBackColor">
        <h1 class = "mainTitle">新規登録</h1>

        <!-- Authによっていい感じになるらしい -->
        <form action = "<?php echo e(route('register')); ?>"　name = "registerform" method = "post">
            <!-- 入力値チェックええ感じに検査してくれるらしい -->
            <?php echo csrf_field(); ?>
            <!-- $errors -> first（'【フィールド名】'）：　入力した後に入力値をチェックする仕組み（＝バリデーション） -->
	<div class="register_labels_and_buttons">
	 <div class = "login_labels">
	
           <font color="red">※</font> <label for = "name">ユーザ名</label>
	    <input type  = "text" name = "name" class = "register_label_name" placeholder="12文字以下で入力してください。" autofocus>		
<div class = "errors_msg"><?php echo e($errors -> first('name')); ?></div>


            <font color="red">※</font><label for = "password">パスワード</label>
	    <input type = "password" name = "password" class = "register_label_password" placeholder="8文字以上で入力してください。">
	    <div class = "errors_msg"><?php echo e($errors -> first('password')); ?></font></div>

	    <font color="red">※</font><label for = "password">パスワード(確認用)</label>
	    <input type = "password" name = "password_confirmation" class = "register_label_password_confirmation" placeholder="同じパスワードを入力してください。">
	    <div = "errors_msg"><?php echo e($errors -> first('password_confirmation')); ?></font></div>
		<font color="red">※は必須項目です。</font>
	</div>
    <div class="register_buttons"> <!--spanはインライン要素らしい-->
            <input type = "submit" name = "action" class = "Registration_button" value = "登録">
        </form>

        <!-- カレンダー画面へ -->
        <form  method = "post" action = <?php echo e(route ('index')); ?>>
            <?php echo csrf_field(); ?>
            <input type = "submit" class = "register_cancel_button" value = "キャンセル">
        </form>
    </div>
   </div>     
</div>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eaton\resources\views/auth/register.blade.php ENDPATH**/ ?>