<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Http\Request;
class IndexCSVController extends Controller
{
    public function whiteCSV(){
        //DB取得
        $tasks = \DB::table('tasks')->get();

        // CSVファイルに書き込む配列を定義します。
        $ary = array(
            array("id","userName","title","class","place","start_date","start_time","end_date","end_time","remarks","last_editor","created_at","updated_at","deleted_at"),
        );

        foreach ($tasks as $task){
            array_push($ary, array($task->id, $task->userName, $task->title, $task->class, $task->place, $task->start_date, $task->start_time, $task->end_date, $task->end_time, $task->remarks, $task->last_editor, $task->created_at, $task->updated_at, $task->deleted_at));
        }

        // ファイルを書き込み用に開きます。
        $f = fopen(date("Y_m_d_")."tasks_date.csv", "w");
        // 正常にファイルを開くことができていれば、書き込みます。
        if ( $f ) {
            // $ary から順番に配列を呼び出して書き込みます。
            foreach($ary as $line){
                // fputcsv関数でファイルに書き込みます。
                fputcsv($f, $line);
            }
        }
        // ファイルを閉じます。
        fclose($f);
        return redirect('');
    }

}
